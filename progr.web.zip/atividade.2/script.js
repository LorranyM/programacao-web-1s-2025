var els = document.querySelectorAll("#tags button");
for(i=0; i < els.length; i++){
   els[i].addEventListener("click", function(){
      var soma = parseInt(this.getAttribute("n"))+1;
      this.setAttribute("n",soma);
      this.innerText = soma;
   });
}